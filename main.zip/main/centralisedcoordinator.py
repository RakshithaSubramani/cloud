import queue
import threading
import time
request_queue = queue.Queue()
def coordinator():
    while not request_queue.empty():
        process = request_queue.get()
        print(f"Coordinator grants access to Process {process}")
        print(f"Process {process} ENTERED Critical Section")
        time.sleep(2)
        print(f"Process {process} EXITED Critical Section")
        print("Coordinator ready for next request.\n")
request_queue.put(1)
request_queue.put(2)
request_queue.put(3)
coordinator_thread = threading.Thread(target=coordinator)
coordinator_thread.start()
coordinator_thread.join()

class Process:
    def __init__(self, name):
        self.name = name
        self.clock = 0

    def event(self):
        self.clock += 1
        print(f"{self.name} performs an event. Clock = {self.clock}")

    def send_message(self, receiver):
        self.clock += 1
        timestamp = self.clock
        print(f"{self.name} sends message to {receiver.name} with timestamp {timestamp}")
        receiver.receive_message(timestamp)
    def receive_message(self, timestamp):
        self.clock = max(self.clock, timestamp) + 1
        print(f"{self.name} receives message. Clock = {self.clock}")

P1 = Process("P1")
P2 = Process("P2")
P3 = Process("P3")
P1.event()
P1.send_message(P2)
P2.event()
P2.send_message(P3)
P3.event()
P3.send_message(P1)
P1.event()

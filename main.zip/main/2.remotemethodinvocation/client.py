import Pyro4
# Enter the URI displayed by the server
uri = input("Enter the Server URI: ")
# Connect to the remote object
calculator = Pyro4.Proxy(uri)
# Get user input
a = int(input("Enter first number: "))
b = int(input("Enter second number: "))
# Remote method invocation
sum_result = calculator.add_numbers(a, b)
product_result = calculator.multiply(a, b)
# Display results
print("\nResults from Remote Server")
print("Addition =", sum_result)
print("Multiplication =", product_result)


'''
pip install pyro4
while running client will ask host uri
it will be like :  PYRO:obj_d7d0779ead0641ec902cc26c8141a7f2@localhost:50729
paste it in client terminal
'''
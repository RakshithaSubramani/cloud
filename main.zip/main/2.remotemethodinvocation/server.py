import Pyro4
@Pyro4.expose
class Calculator:
    def add_numbers(self, a, b):
        return a + b
    def multiply(self, a, b):
        return a * b
# Create a Pyro daemon
daemon = Pyro4.Daemon()
# Register the Calculator object
uri = daemon.register(Calculator)
print("Calculator Server is running...")
print("URI:", uri)
# Start the server
daemon.requestLoop()

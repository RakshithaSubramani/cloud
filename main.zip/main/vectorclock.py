class Process:
    def __init__(self, name, pid, total_processes):
        self.name = name
        self.pid = pid
        self.vector = [0] * total_processes

    def event(self):
        self.vector[self.pid] += 1
        print(f"{self.name} performs an event. Vector = {self.vector}")

    def send_message(self, receiver):
        self.vector[self.pid] += 1
        timestamp = self.vector.copy()
        print(f"{self.name} sends message to {receiver.name}")
        print("Timestamp:", timestamp)
        receiver.receive_message(timestamp)

    def receive_message(self, received_vector):
        for i in range(len(self.vector)):
            self.vector[i] = max(self.vector[i], received_vector[i])
        self.vector[self.pid] += 1
        print(f"{self.name} receives message.")
        print("Updated Vector:", self.vector)

n = 3
P1 = Process("P1", 0, n)
P2 = Process("P2", 1, n)
P3 = Process("P3", 2, n)
P1.event()
P1.send_message(P2)
P2.event()
P2.send_message(P3)
P3.event()
P3.send_message(P1)
P1.event()

import socket
import pickle
class DataObject:
    def __init__(self, name, values):
        self.name = name
        self.values = values
HOST = '127.0.0.1'
PORT = 5001
client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect((HOST, PORT))
name = input("Enter Name: ")
values = list(map(int, input("Enter numbers separated by space: ").split()))
obj = DataObject(name, values)
client.send(pickle.dumps(obj))
response = pickle.loads(client.recv(4096))
print(response)
client.close()

import socket
import threading
HOST = '127.0.0.1'
PORT = 5000
client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect((HOST, PORT))
def receive():
    while True:
        try:
            message = client.recv(1024).decode()
            print(message)
        except:
            break
threading.Thread(target=receive).start()
while True:
    msg = input()
    client.send(msg.encode())

'''
run client in multiple terminals and send messages
'''
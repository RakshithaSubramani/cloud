
import socket
import threading
HOST = '127.0.0.1'
PORT = 5000
clients = []
def broadcast(message, client):
    for c in clients:
        if c != client:
            try:
                c.send(message)
            except:
                clients.remove(c)
def handle_client(client):
    while True:
        try:
            message = client.recv(1024)
            if not message:
                break
            print("Received:", message.decode())
            broadcast(message, client)
        except:
            break
    clients.remove(client)
    client.close()
server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind((HOST, PORT))
server.listen()
print("Server started...")
while True:
    client, addr = server.accept()
    print("Connected:", addr)
    clients.append(client)
    thread = threading.Thread(target=handle_client, args=(client,))
    thread.start()

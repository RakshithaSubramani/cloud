import time
n = 4
token = 0
for _ in range(8):
    print(f"\nToken is with Process {token}")
    print(f"Process {token} ENTERED Critical Section")
    time.sleep(1)
    print(f"Process {token} EXITED Critical Section")
    token = (token + 1) % n

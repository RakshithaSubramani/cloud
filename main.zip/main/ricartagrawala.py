import threading
import time
class Process:
    def __init__(self, pid):
        self.pid = pid
    def request_cs(self):
        print(f"Process {self.pid} is requesting the Critical Section...")
        time.sleep(1)
        print("Sending REQUEST messages to all other processes...")
        time.sleep(1)
        print("Received REPLY from all processes.")
        print(f"Process {self.pid} ENTERED Critical Section")
        time.sleep(2)
        print(f"Process {self.pid} EXITED Critical Section")
        print("Sending deferred REPLY messages.")
p = Process(1)
t = threading.Thread(target=p.request_cs)
t.start()
t.join()
